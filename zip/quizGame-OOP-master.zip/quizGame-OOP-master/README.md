# quizGame-OOP
This is a project where the aim is to build a quiz game using Java, classes and OOP principles that can be played completely by interacting via the command line.
